<?php
namespace Renuka\Override\Model;

/**
 * Class AbstractAction
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
abstract class AbstractTemplate extends \Magento\Email\Model\AbstractTemplate 
{

     public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Email\Model\Template\Config $emailConfig,
        array $data = []
    ) {
        $this->emailConfig = $emailConfig;
    }

    public function setForcedArea($templateId)
    {
    return "hello";
    // if (!isset($this->area)) {
    //     $this->area = $this->emailConfig->getTemplateArea($templateId);
    // }
    // return $this;
}
}